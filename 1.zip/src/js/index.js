import '../scss/style.scss'
import Swiper from 'swiper'
// import '../../node_modules/swiper/swiper-bundle.css'
import 'swiper/css/bundle'
import { Navigation, Pagination } from 'swiper/modules'

console.log('Works!')

//Main-style-js
const mediaQuery_320px = window.matchMedia(
  '(min-width: 320px) and (max-width: 767px)'
)
const mediaQuery_768px = window.matchMedia(
  '(min-width: 768px) and (max-width: 1120px)'
)
const mediaQuery_1121px = window.matchMedia('(min-width: 1121px)')

const buttonDescriptionReadMore = document.querySelector(
  '.description-read-more__button-read-more'
)
const buttonDescriptionHiddenMore = document.querySelector(
  '.description-read-more__button-hidden-more'
)
const descriptionForAll = document.querySelector('.description__for-all')
const descriptionForTablet = document.querySelector('.description__for-tablet')
const descriptionForDesktop = document.querySelector(
  '.description__for-desktop'
)

buttonDescriptionReadMore.addEventListener('click', function (evt) {
  console.log('buttonDescriptionReadMore')
  descriptionForTablet.classList.add('show')
  descriptionForDesktop.classList.add('show')
  buttonDescriptionReadMore.classList.add('hidden')
  buttonDescriptionHiddenMore.classList.remove('hidden')
})

buttonDescriptionHiddenMore.addEventListener('click', function (evt) {
  console.log('buttonDescriptionHiddenMore')
  if (mediaQuery_320px) {
    descriptionForTablet.classList.remove('show')
    descriptionForDesktop.classList.remove('show')
  }
  if (mediaQuery_768px) {
    descriptionForDesktop.classList.remove('show')
  }
  buttonDescriptionHiddenMore.classList.add('hidden')
  buttonDescriptionReadMore.classList.remove('hidden')
})
//Конец main-style-js

//js бренды + слайдер
const buttonReadMoreBrand = document.querySelector('.button-read-more')
const buttonHiddenBrand = document.querySelector('.hidden-more')
const allSliderElementBrand = document.querySelectorAll('.swiper-slide')
let sliderElementBrandHiddenShow = []
const a = 0
// const mediaQuery_768px = window.matchMedia(
//   '(min-width: 768px) and (max-width: 1120px)'
// )

// const mediaQuery_1121px = window.matchMedia('(min-width: 1121px)')

if (mediaQuery_768px.matches) {
  sliderElementBrandHiddenShow = document.querySelectorAll(
    '.swiper-slide:nth-last-child(-n+5)'
  )
}
if (mediaQuery_1121px.matches) {
  sliderElementBrandHiddenShow = document.querySelectorAll(
    '.swiper-slide:nth-last-child(-n+3)'
  )
}

//Слушатель кнопки показать все
buttonReadMoreBrand.addEventListener('click', function (evt) {
  evt.preventDefault()
  console.log('Показать все')
  buttonReadMoreBrand.classList.add('hidden')
  buttonHiddenBrand.classList.remove('hidden')
  console.log(allSliderElementBrand)
  for (let i = 0; i < allSliderElementBrand.length; i++) {
    allSliderElementBrand[i].classList.add('show')
  }
})
//Слушатель кнопки скрыть
buttonHiddenBrand.addEventListener('click', function () {
  console.log('Скрыть')
  buttonHiddenBrand.classList.add('hidden')
  buttonReadMoreBrand.classList.remove('hidden')
  for (let i = 0; i < sliderElementBrandHiddenShow.length; i++) {
    sliderElementBrandHiddenShow[i].classList.remove('show')
  }
})

//Слайдер
window.addEventListener('DOMContentLoaded', () => {
  const resizableSwiper = (
    breakpoint,
    swiperClass,
    swiperSettings,
    callback
  ) => {
    let swiper

    breakpoint = window.matchMedia(breakpoint)

    const enableSwiper = function (className, settings) {
      swiper = new Swiper(className, settings)

      if (callback) {
        callback(swiper)
      }
    }

    const checker = function () {
      if (breakpoint.matches) {
        return enableSwiper(swiperClass, swiperSettings)
      } else {
        if (swiper !== undefined) swiper.destroy(true, true)
        return
      }
    }

    breakpoint.addEventListener('change', checker)
    checker()
  }

  resizableSwiper('(max-width: 768px)', '.swiper-brands', {
    modules: [Pagination, Navigation],
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev'
    },
    pagination: {
      el: '.swiper-pagination',
      type: 'bullets',
      clickable: true
    },
    loop: true,
    freeMode: true,
    slidesPerView: 1.2,
    spaceBetween: 16,
    breakpoints: {
      320: {
        slidesPerView: 1.25
      },
      420: {
        slidesPerView: 1.7
      },
      520: {
        slidesPerView: 2
      },
      620: {
        slidesPerView: 2.5
      },
      720: {
        slidesPerView: 3
      }
    }
  })
})
//конец js бренды + слайдер
